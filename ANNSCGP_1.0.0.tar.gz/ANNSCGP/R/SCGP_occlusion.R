#' @title SCGP_occlusion
#'
#' @description Calculate the occlusion scores of each input node.
#'
#' @param data Input matrix. Rows are samples and columns are nodes.
#'
#' @param weight Weight in ANN-SCGP model.
#'
#' @param bias Bias in ANN-SCGP model.
#'
#' @return A data.frame, containing occlusion scores of each input node
#'
#' @examples imp_occlusion=SCGP_occlusion(data,weight,bias)
#'
#' @export SCGP_occlusion


SCGP_occlusion=function(data,weight,bias){

  genename=colnames(data)
  output=simple_train(data,weight,bias)

  she=NA
  for (t in 1:length(genename)){
    weight_new=weight
    weight_new[[1]][genename[t],]=0
    output_new=simple_train(data,weight_new,bias)

    she=c(she,sum(abs(output-output_new)))
    print(t)
  }
  gene_importance=data.frame(ID=genename,Influence=she[-1])
  return(gene_importance)
}

