#' @title SCGP_perturbation
#'
#' @description Calculate the perturbation scores of each input node.
#'
#' @param data Input matrix. Rows are samples and columns are nodes.
#'
#' @param weight Weight in ANN-SCGP model.
#'
#' @param bias Bias in ANN-SCGP model.
#'
#' @return A data.frame, containing perturbation scores of each input node
#'
#' @examples imp_perturbation=SCGP_perturbation(data,weight,bias)
#'
#' @export SCGP_perturbation

SCGP_perturbation_step1=function(data,weight,bias,rate){
  genename=colnames(data)
  output=simple_train(data,weight,bias)

  she=NA
  for (t in 1:length(genename)){
    data2=data
    data2[,genename[t]]=data2[,genename[t]]*(1+rate)
    output_new=simple_train(data2,weight,bias)

    she=c(she,sum(abs((output_new-output))))
    print(t)
  }
  gene_importance=data.frame(ID=genename,Influence=she[-1])
  return(gene_importance)
}

SCGP_perturbation=function(data,weight,bias){
  genename=colnames(data)
  rao=matrix(NA,ncol(data),10)
  for (t in 1:10){
    rao[,t]=SCGP_perturbation_step1((data+0.1),weight,bias,rate=(0.1*t))$Influence
  }
  rownames(rao)=genename
  AUC=NA
  for (t in 1:length(genename)){
    AUC=c(AUC,pracma::trapz(c(0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1),rao[genename[t],]))
  }
  imp_perturbation=data.frame(ID=genename,Influence=AUC[-1])
  return(imp_perturbation)
}
