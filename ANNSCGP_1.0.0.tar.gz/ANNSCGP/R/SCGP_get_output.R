#' @title SCGP_get_output
#'
#' @description Get output value of ANN-SCGP model.
#'
#' @param data Input matrix. Rows are samples and columns are nodes.
#'
#' @param SCGP_res Output of SCGP_train function.
#'
#' @return Output value.
#'
#' @examples output=SCGP_get_output(data,SCGP_res)
#'
#' @examples validate_output=SCGP_get_output(validate_data,SCGP_res)
#'
#' @export SCGP_get_output


SCGP_get_output=function(data,SCGP_res){
  alpha=parameters$alpha
  lambda=parameters$lambda
  acf=parameters$acf
  outf=parameters$outf

  weight=SCGP_res$weight
  bias=SCGP_res$bias
  hidden_layer_input=list()
  hidden_layer_active=list()
  if  (length(weight)>=3){
    hidden_layer_input[[1]]=as.matrix(data)%*%as.matrix(weight[[1]])
    hidden_layer_input[[1]]=hidden_layer_input[[1]]+bias[[1]]
    hidden_layer_active[[1]]=acf(hidden_layer_input[[1]])
    for (w in 2:(length(weight)-1)){
      hidden_layer_input[[w]]=as.matrix(hidden_layer_active[[(w-1)]])%*%as.matrix(weight[[w]])
      hidden_layer_input[[w]]=hidden_layer_input[[w]]+bias[[w]]
      hidden_layer_active[[w]]=acf(hidden_layer_input[[w]])
    }
    hidden_layer_input[[length(weight)]]=as.matrix(hidden_layer_active[[(length(weight)-1)]])%*%as.matrix(weight[[length(weight)]])
    hidden_layer_input[[length(weight)]]=hidden_layer_input[[length(weight)]]+bias[[length(weight)]]
    hidden_layer_active[[length(weight)]]=outf(hidden_layer_input[[length(weight)]])}
  if  (length(weight)==1){
    hidden_layer_input[[1]]=as.matrix(data)%*%as.matrix(weight[[1]])
    hidden_layer_input[[1]]=hidden_layer_input[[1]]+bias[[1]]
    hidden_layer_active[[1]]=outf(hidden_layer_input[[1]])}
  if  (length(weight)==2){
    hidden_layer_input[[1]]=as.matrix(data)%*%as.matrix(weight[[1]])
    hidden_layer_input[[1]]=hidden_layer_input[[1]]+bias[[1]]
    hidden_layer_active[[1]]=acf(hidden_layer_input[[1]])

    hidden_layer_input[[2]]=as.matrix(hidden_layer_active[[(1)]])%*%as.matrix(weight[[2]])
    hidden_layer_input[[2]]=hidden_layer_input[[2]]+bias[[2]]
    hidden_layer_active[[2]]=outf(hidden_layer_input[[2]])}
  return(hidden_layer_active[[length(weight)]])
}
