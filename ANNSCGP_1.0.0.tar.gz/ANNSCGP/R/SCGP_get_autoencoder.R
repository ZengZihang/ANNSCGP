#' @title SCGP_get_autoencoder
#'
#' @description Get output value of autoencoder model.
#'
#' @param data Input matrix. Rows are samples and columns are nodes.
#'
#' @param SCGP_res Output of SCGP_autoencoder function.
#'
#' @return Output value.
#'
#' @examples output=SCGP_get_autoencoder(data,SCGP_res)
#'
#' @examples validate_output=SCGP_get_autoencoder(validate_data,SCGP_res)
#'
#' @export SCGP_get_autoencoder
dev_ReLU<-function(x){
  x[x<=0]=0
  x[x>0]=1
  return(x)
}
ReLU<-function(x){
  x[x<=0]=0
  return(x)
}
identity<-function(x){return(x)}
dev_identity<-function(x){return(rep(1,length(x)))}

SCGP_get_autoencoder=function(data,SCGP_res){
  alpha=1
  acf=ReLU
  outf=identity
  derivatives_outf=dev_identity
  derivatives_acf=dev_ReLU

  weight=SCGP_res$weight
  bias=SCGP_res$bias
  hidden_layer_input=list()
  hidden_layer_active=list()
  num=(length(SCM.auto$weight))/2


  if  (length(weight)>=3){
    hidden_layer_input[[1]]=as.matrix(data)%*%as.matrix(weight[[1]])
    hidden_layer_input[[1]]=hidden_layer_input[[1]]+bias[[1]]
    hidden_layer_active[[1]]=acf(hidden_layer_input[[1]])
    for (w in 2:(length(weight)-1)){
      hidden_layer_input[[w]]=as.matrix(hidden_layer_active[[(w-1)]])%*%as.matrix(weight[[w]])
      hidden_layer_input[[w]]=hidden_layer_input[[w]]+bias[[w]]
      hidden_layer_active[[w]]=acf(hidden_layer_input[[w]])
    }
    hidden_layer_input[[length(weight)]]=as.matrix(hidden_layer_active[[(length(weight)-1)]])%*%as.matrix(weight[[length(weight)]])
    hidden_layer_input[[length(weight)]]=hidden_layer_input[[length(weight)]]+bias[[length(weight)]]
    hidden_layer_active[[length(weight)]]=outf(hidden_layer_input[[length(weight)]])}
  if  (length(weight)==1){
    hidden_layer_input[[1]]=as.matrix(data)%*%as.matrix(weight[[1]])
    hidden_layer_input[[1]]=hidden_layer_input[[1]]+bias[[1]]
    hidden_layer_active[[1]]=outf(hidden_layer_input[[1]])}
  if  (length(weight)==2){
    hidden_layer_input[[1]]=as.matrix(data)%*%as.matrix(weight[[1]])
    hidden_layer_input[[1]]=hidden_layer_input[[1]]+bias[[1]]
    hidden_layer_active[[1]]=acf(hidden_layer_input[[1]])

    hidden_layer_input[[2]]=as.matrix(hidden_layer_active[[(1)]])%*%as.matrix(weight[[2]])
    hidden_layer_input[[2]]=hidden_layer_input[[2]]+bias[[2]]
    hidden_layer_active[[2]]=outf(hidden_layer_input[[2]])}
  return(hidden_layer_active[[num]])
}
