#' @title SCGP_train
#'
#' @description Train a supervised ANN-SCGP model.
#'
#' @param NULL
#'
#' @return A list, containing weigh, bias and error value (cost and validate_cost) of ANN-SCGP model
#'
#' @examples NULL
#'
#' @export SCGP_train


###Activation function and its derivative
LReLU<-function(x){
  x[x<=0]=alpha*x[x<=0]
  return(x)
}
ReLU<-function(x){
  x[x<=0]=0
  return(x)
}
sigmoid<-function(x){
  return(1/(1+exp(-x)))
}
anti_sigmoid<-function(x){
  return(-log((1/x)-1))}
tanh<-function(x){
  return((exp(x)-exp(-x))/(exp(x)+exp(-x)))
}
ELU<-function(x){
  x[x<=0]=alpha*(exp(x[x<=0])-1)
  return(x)
}
origin<-function(x){return(x)}
SELU<-function(x){
  x=x*lambda
  x[x<=0]=alpha*(exp(x[x<=0])-1)
  return(x)
}
identity<-function(x){return(alpha*x)}
dev_LReLU<-function(x){
  x[x<=0]=alpha
  x[x>0]=1
  return(x)
}
dev_ReLU<-function(x){
  x[x<=0]=0
  x[x>0]=1
  return(x)
}
dev_sigmoid<-function(x){
  x=sigmoid(x)*(1-sigmoid(x))
  return(x)
}
dev_tanh<-function(x){
  x=1-(tanh(x)^2)
  return(x)
}
dev_ELU<-function(x){
  x1=x
  x1[x>0]=1
  x1[x<=0]=ELU(x)[x<=0]+alpha
  return(x1)
}
dev_SELU<-function(x){
  x1=x
  x1[x>0]=lambda
  x1[x<=0]=(SELU(x)[x<=0]+alpha)*lambda
  return(x1)
}
dev_identity<-function(x){return(rep(alpha,length(x)))}
dev_origin<-function(x){return(rep(1,length(x)))}

###Initialization


  SCGP_layer_weight_Xavier=function(data,option){
    weight=list()
    weight[[1]]=matrix( rnorm(ncol(data)*option[1],mean=0,sd=1)*sqrt(2.0/(ncol(data)+option[1])), ncol(data),option[1])
    if (length(option)>=2){
      for (t in 2:(length(option))){
        weight[[t]]=matrix( rnorm(option[(t-1)]*option[(t)],mean=0,sd=1)*sqrt(2.0/(option[(t-1)]+option[(t)])), option[(t-1)],option[(t)])
      }}
    rownames(weight[[1]])=colnames(data)
    return(weight)
  }
  SCGP_layer_bias_Xavier=function(data,option){
    bias=list()
    for (t in 1:(length(option))){
      bias[[t]]=0
    }
    return(bias)
  }


  SCGP_layer_weight_He=function(data,option){
    weight=list()
    weight[[1]]=matrix( rnorm(ncol(data)*option[1],mean=0,sd=1)*sqrt(2.0/(option[1])), ncol(data),option[1])
    if (length(option)>=2){
      for (t in 2:(length(option))){
        weight[[t]]=matrix( rnorm(option[(t-1)]*option[(t)],mean=0,sd=1)*sqrt(2.0/(option[(t)])), option[(t-1)],option[(t)])
      }}
    rownames(weight[[1]])=colnames(data)
    return(weight)
  }
  SCGP_layer_bias_He=function(data,option){
    bias=list()
    for (t in 1:(length(option))){
      bias[[t]]=0
    }
    return(bias)
  }

#####
simple_train=function(data,weight,bias){
  hidden_layer_input=list()
  hidden_layer_active=list()
  alpha=parameters$alpha
  lambda=parameters$lambda
  acf=parameters$acf
  outf=parameters$outf
  if  (length(weight)>=3){
    hidden_layer_input[[1]]=as.matrix(data)%*%as.matrix(weight[[1]])
    hidden_layer_input[[1]]=hidden_layer_input[[1]]+bias[[1]]
    hidden_layer_active[[1]]=acf(hidden_layer_input[[1]])
    for (w in 2:(length(weight)-1)){
      hidden_layer_input[[w]]=as.matrix(hidden_layer_active[[(w-1)]])%*%as.matrix(weight[[w]])
      hidden_layer_input[[w]]=hidden_layer_input[[w]]+bias[[w]]
      hidden_layer_active[[w]]=acf(hidden_layer_input[[w]])
    }
    hidden_layer_input[[length(weight)]]=as.matrix(hidden_layer_active[[(length(weight)-1)]])%*%as.matrix(weight[[length(weight)]])
    hidden_layer_input[[length(weight)]]=hidden_layer_input[[length(weight)]]+bias[[length(weight)]]
    hidden_layer_active[[length(weight)]]=outf(hidden_layer_input[[length(weight)]])}
  if  (length(weight)==1){
    hidden_layer_input[[1]]=as.matrix(data)%*%as.matrix(weight[[1]])
    hidden_layer_input[[1]]=hidden_layer_input[[1]]+bias[[1]]
    hidden_layer_active[[1]]=outf(hidden_layer_input[[1]])}
  if  (length(weight)==2){
    hidden_layer_input[[1]]=as.matrix(data)%*%as.matrix(weight[[1]])
    hidden_layer_input[[1]]=hidden_layer_input[[1]]+bias[[1]]
    hidden_layer_active[[1]]=acf(hidden_layer_input[[1]])

    hidden_layer_input[[2]]=as.matrix(hidden_layer_active[[(1)]])%*%as.matrix(weight[[2]])
    hidden_layer_input[[2]]=hidden_layer_input[[2]]+bias[[2]]
    hidden_layer_active[[2]]=outf(hidden_layer_input[[2]])}
  return(hidden_layer_active[[length(weight)]])
}

###################################
SCGP_train=function(data,clin,option,SCM,parameters,validate_data,validate_clin,survival_analyis,gene_monitoring,learning_function,initialization_method){

  if (missing(parameters)) {parameters=list(alpha=1.67326324235,
                                            lambda=1.05070098736,
                                            learning_rate=0.00001,
                                            acf=SELU,
                                            outf=origin,
                                            derivatives_outf=dev_origin,
                                            derivatives_acf=dev_SELU,
                                            training_n=100000,
                                            message_n=2,
                                            termination_threshold=0.95,
                                            greater_than_termination_threshold=T,
                                            L2_w=0)}

  SCGP_res=SCGP_process_train_loglink(data,clin,option,SCM,parameters=parameters,validate_data,validate_clin,survival_analyis,gene_monitoring,learning_function,termination_threshold,greater_than_termination_threshold,initialization_method)
  return(SCGP_res)
}




#############################
SCGP_process_train_loglink=function(data,clin,option,SCM,parameters,validate_data,validate_clin,survival_analyis,gene_monitoring,learning_function,termination_threshold,greater_than_termination_threshold,initialization_method){
require(survival)
  ###############parameter
  alpha=parameters$alpha
  termination_threshold=parameters$termination_threshold
  greater_than_termination_threshold=parameters$greater_than_termination_threshold
  lambda=parameters$lambda
  learning_rate=parameters$learning_rate
  acf=parameters$acf
  outf=parameters$outf
  derivatives_outf=parameters$derivatives_outf
  derivatives_acf=parameters$derivatives_acf
  training_n=parameters$training_n
  message_n=parameters$message_n
  L2_w=parameters$L2_w
  weight_selective=SCM
  if (missing(survival_analyis)) stop("Are labels survival data? Please set the survival_analyis parameter.")
  if (missing(option)) stop("There is no option data.")
  if (missing(gene_monitoring)) gene_monitoring=0
  if (missing(learning_function)) learning_function=1
  if (missing(data)) stop("There is no input data.")
  if (missing(data)) stop("There is no label data.")
  if (missing(SCM)) stop("There is no SCM.")
  learning_r=learning_rate*learning_function
  if (missing(initialization_method)) initialization_method="Xavier"
  if (initialization_method=="Xavier"){
    SCGP_layer_weight=SCGP_layer_weight_Xavier
    SCGP_layer_bias=SCGP_layer_bias_Xavier
  }
  if (initialization_method=="He"){
    SCGP_layer_weight=SCGP_layer_weight_He
    SCGP_layer_bias=SCGP_layer_bias_He

  }

  if(survival_analyis==T){
  events=rownames(clin)[clin$status==1]
  labels=matrix(clin$time,nrow(data),1)
  rownames(labels)=rownames(data)
  validate_labels=matrix(validate_clin$time,nrow(validate_data),1)
  rownames(validate_labels)=rownames(validate_data)
  }else{
    labels=clin
    validate_labels=validate_clin
  }



options=as.numeric(lapply(option,sum))
weight=SCGP_layer_weight(data,options)
bias=SCGP_layer_bias(data,options)

  hidden_layer_input=list()
  hidden_layer_active=list()
  d_hidden_layer=list()
  Error_at_hidden_layer=list()
  slope_hidden_layer=list()
  cost=1
  validate_cost=NA
  node_monitoring=NA
  simple_train=function(data,weight,bias){
    hidden_layer_input=list()
    hidden_layer_active=list()
    if  (length(weight)>=3){
      hidden_layer_input[[1]]=as.matrix(data)%*%as.matrix(weight[[1]])
      hidden_layer_input[[1]]=hidden_layer_input[[1]]+bias[[1]]
      hidden_layer_active[[1]]=acf(hidden_layer_input[[1]])
      for (w in 2:(length(weight)-1)){
        hidden_layer_input[[w]]=as.matrix(hidden_layer_active[[(w-1)]])%*%as.matrix(weight[[w]])
        hidden_layer_input[[w]]=hidden_layer_input[[w]]+bias[[w]]
        hidden_layer_active[[w]]=acf(hidden_layer_input[[w]])
      }
      hidden_layer_input[[length(weight)]]=as.matrix(hidden_layer_active[[(length(weight)-1)]])%*%as.matrix(weight[[length(weight)]])
      hidden_layer_input[[length(weight)]]=hidden_layer_input[[length(weight)]]+bias[[length(weight)]]
      hidden_layer_active[[length(weight)]]=outf(hidden_layer_input[[length(weight)]])}
    if  (length(weight)==1){
      hidden_layer_input[[1]]=as.matrix(data)%*%as.matrix(weight[[1]])
      hidden_layer_input[[1]]=hidden_layer_input[[1]]+bias[[1]]
      hidden_layer_active[[1]]=outf(hidden_layer_input[[1]])}
    if  (length(weight)==2){
      hidden_layer_input[[1]]=as.matrix(data)%*%as.matrix(weight[[1]])
      hidden_layer_input[[1]]=hidden_layer_input[[1]]+bias[[1]]
      hidden_layer_active[[1]]=acf(hidden_layer_input[[1]])

      hidden_layer_input[[2]]=as.matrix(hidden_layer_active[[(1)]])%*%as.matrix(weight[[2]])
      hidden_layer_input[[2]]=hidden_layer_input[[2]]+bias[[2]]
      hidden_layer_active[[2]]=outf(hidden_layer_input[[2]])}
    return(hidden_layer_active[[length(weight)]])
  }


  #### Training
  for(i in 1:training_n){


    #### Forward propagation
    weight[[1]][weight_selective==0]=0
    hidden_layer_input[[1]]=as.matrix(data)%*%as.matrix(weight[[1]])
    hidden_layer_input[[1]]=hidden_layer_input[[1]]+bias[[1]]
    if(length(weight)==1){
      hidden_layer_active[[length(weight)]]=outf(hidden_layer_input[[length(weight)]])
    }else{
      if(length(weight)==2){

        hidden_layer_active[[1]]=acf(hidden_layer_input[[1]])
        hidden_layer_input[[length(weight)]]=as.matrix(hidden_layer_active[[(length(weight)-1)]])%*%as.matrix(weight[[length(weight)]])
        hidden_layer_input[[length(weight)]]=hidden_layer_input[[length(weight)]]+bias[[length(weight)]]
        hidden_layer_active[[length(weight)]]=outf(hidden_layer_input[[length(weight)]])
        }else{



    hidden_layer_active[[1]]=acf(hidden_layer_input[[1]])
    for (w in 2:(length(weight)-1)){
      hidden_layer_input[[w]]=as.matrix(hidden_layer_active[[(w-1)]])%*%as.matrix(weight[[w]])
      hidden_layer_input[[w]]=hidden_layer_input[[w]]+bias[[w]]
      hidden_layer_active[[w]]=acf(hidden_layer_input[[w]])
    }
    hidden_layer_input[[length(weight)]]=as.matrix(hidden_layer_active[[(length(weight)-1)]])%*%as.matrix(weight[[length(weight)]])
    hidden_layer_input[[length(weight)]]=hidden_layer_input[[length(weight)]]+bias[[length(weight)]]
    hidden_layer_active[[length(weight)]]=outf(hidden_layer_input[[length(weight)]])
    }}
    #### Back Propagation
Error_at_hidden_layer[[length(weight)]]=labels-hidden_layer_active[[length(weight)]]

    if(survival_analyis==T){ Error_at_hidden_layer[[length(weight)]][!rownames(Error_at_hidden_layer[[length(weight)]])%in%events,1][Error_at_hidden_layer[[length(weight)]][!rownames(Error_at_hidden_layer[[length(weight)]])%in%events,1]<=0]=0
   }

    slope_hidden_layer[[length(weight)]]=derivatives_outf(hidden_layer_input[[length(weight)]])
    d_hidden_layer[[length(weight)]]=Error_at_hidden_layer[[length(weight)]]*slope_hidden_layer[[length(weight)]]



    if(length(weight)==1){
      weight[[1]]=weight[[1]]-d_hidden_layer[[1]]*learning_r-L2_w*(weight[[1]])*learning_r
      bias[[1]]= bias[[1]]
    }else{
     for (w in (length(weight)-1):1){
      Error_at_hidden_layer[[w]]=d_hidden_layer[[(w+1)]]%*%t(weight[[(w+1)]])
      slope_hidden_layer[[w]]=derivatives_acf(hidden_layer_input[[w]])
      d_hidden_layer[[w]]=Error_at_hidden_layer[[w]]*slope_hidden_layer[[w]]
    }
    for (w in (length(weight)):2){
      weight[[w]]=weight[[w]]+(t(hidden_layer_active[[(w-1)]])%*%d_hidden_layer[[w]])*learning_r-L2_w*(weight[[w]])*learning_r
      bias[[w]]= bias[[w]]+colSums(d_hidden_layer[[w]])*learning_r
    }
    weight[[1]]=weight[[1]]+(t(data)%*%d_hidden_layer[[1]])*learning_r-L2_w*(weight[[1]])*learning_r
    bias[[1]]= bias[[1]]+colSums(d_hidden_layer[[1]])*learning_r

        weight[[1]][weight_selective==0]=0

}


    output=simple_train(data,weight,bias)
    if(survival_analyis==T){
    cost=c(cost,summary(coxph(Surv(clin$time,clin$status)~output))$concordance[1])
    }else{cost=c(cost,apply(abs(labels-output),2,mean))}


    if (gene_monitoring!=0){
      cost_raw= mean(abs(output-labels))
      weight_new=weight
      weight_new[[1]]["gene_monitoring",]=0
      output_new=simple_train(data,weight_new,bias)
      cost_new=mean(abs(output_new-labels))
      node_monitoring=c(node_monitoring,(cost_new-cost_raw))
    }


    validate_output=simple_train(validate_data,weight,bias)

    if(survival_analyis==T){
    validate_cost=c(validate_cost,summary(coxph(Surv(validate_clin$time,validate_clin$status)~validate_output))$concordance[1])
    }else{validate_cost=c(validate_cost,apply(abs(validate_labels-validate_output),2,mean))}
    if(i%%message_n==0){
      print(paste("The iteration is",i))
      print(paste("The error value is",cost[length(cost)]))

      print(paste("The validate error value is",validate_cost[length(validate_cost)]))

    }

  }
  if (gene_monitoring!=0){
    SCGP_res=list(weight=weight,bias=bias,cost=cost[-1],validate_cost=validate_cost[-1],node_monitoring=node_monitoring[-1])}else{SCGP_res=list(weight=weight,bias=bias,cost=cost[-1],validate_cost=validate_cost[-1])}

  return(SCGP_res)
}



