#' @title SCGP_GOSemSim
#'
#' @description Calculate GO semantic similarity.
#'
#' @param data Input matrix or gene symbols. Rows are samples and columns are nodes.
#'
#' @return A semantic similarity matrix
#'
#' @examples NULL
#'
#' @export SCGP_GOSemSim

SCGP_GOSemSim<- function(data) {
  if (class(data)=="character"){
    genes=data
  }else{genes=colnames(data)}
  hsBP <- GOSemSim::godata('org.Hs.eg.db', keytype = "SYMBOL", ont="BP", computeIC=FALSE)
  SemBP=GOSemSim::mgeneSim(genes, semData=hsBP, measure="Wang", combine="BMA", verbose=F)
  hsMF <- GOSemSim::godata('org.Hs.eg.db', keytype = "SYMBOL", ont="MF", computeIC=FALSE)
  SemMF=GOSemSim::mgeneSim(genes, semData=hsMF, measure="Wang", combine="BMA", verbose=F)
  hsCC <- GOSemSim::godata('org.Hs.eg.db', keytype = "SYMBOL", ont="CC", computeIC=FALSE)
  SemCC=GOSemSim::mgeneSim(genes, semData=hsCC, measure="Wang", combine="BMA", verbose=F)
  matrix_BP=t(matrix(0, length(genes),length(genes)))
  rownames(matrix_BP)=genes
  colnames(matrix_BP)=genes
  matrix_BP[rownames(SemBP),colnames(SemBP)]=SemBP
  matrix_MF=t(matrix(0, length(genes),length(genes)))
  rownames(matrix_MF)=genes
  colnames(matrix_MF)=genes
  matrix_MF[rownames(SemMF),colnames(SemMF)]=SemMF
  matrix_CC=t(matrix(0, length(genes),length(genes)))
  rownames(matrix_CC)=genes
  colnames(matrix_CC)=genes
  matrix_CC[rownames(SemCC),colnames(SemCC)]=SemCC
  Sem_matrix=(matrix_BP+matrix_MF+matrix_CC)/3
  return(Sem_matrix)
}
