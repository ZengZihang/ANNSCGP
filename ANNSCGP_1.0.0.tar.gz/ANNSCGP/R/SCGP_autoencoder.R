#' @title SCGP_autoencoder
#'
#' @description Train an autoencoder model.
#'
#' @param NULL
#'
#' @return A list, containing weigh, bias and error value (cost and validate_cost) of autoencoder model
#'
#' @examples NULL
#'
#' @export SCGP_autoencoder

dev_ReLU<-function(x){
  x[x<=0]=0
  x[x>0]=1
  return(x)
}
ReLU<-function(x){
  x[x<=0]=0
  return(x)
}
identity<-function(x){return(x)}
dev_identity<-function(x){return(rep(1,length(x)))}

SCGP_autoencoder=function(data,option,learning_rate,training_n,message_n){
  SCGP_auto=SCGP_process_train_autoencoder(data,option,learning_rate,training_n,message_n)
  return(SCGP_auto)
}
SCGP_layer_weight_Xavier=function(data,option){
  weight=list()
  weight[[1]]=matrix( rnorm(ncol(data)*option[1],mean=0,sd=1)*sqrt(2.0/(ncol(data)+option[1])), ncol(data),option[1])
  if (length(option)>=2){
    for (t in 2:(length(option))){
      weight[[t]]=matrix( rnorm(option[(t-1)]*option[(t)],mean=0,sd=1)*sqrt(2.0/(option[(t-1)]+option[(t)])), option[(t-1)],option[(t)])
    }}
  rownames(weight[[1]])=colnames(data)
  return(weight)
}
SCGP_layer_bias_Xavier=function(data,option){
  bias=list()
  for (t in 1:(length(option))){
    bias[[t]]=0
  }
  return(bias)
}


SCGP_layer_weight_He=function(data,option){
  weight=list()
  weight[[1]]=matrix( rnorm(ncol(data)*option[1],mean=0,sd=1)*sqrt(2.0/(option[1])), ncol(data),option[1])
  if (length(option)>=2){
    for (t in 2:(length(option))){
      weight[[t]]=matrix( rnorm(option[(t-1)]*option[(t)],mean=0,sd=1)*sqrt(2.0/(option[(t)])), option[(t-1)],option[(t)])
    }}
  rownames(weight[[1]])=colnames(data)
  return(weight)
}
SCGP_layer_bias_He=function(data,option){
  bias=list()
  for (t in 1:(length(option))){
    bias[[t]]=0
  }
  return(bias)
}

SCGP_process_train_autoencoder=function(data,option,learning_rate,training_n,message_n){
  acf=ReLU
  outf=identity
  derivatives_outf=dev_identity
  derivatives_acf=dev_ReLU
  labels=data
  learning_r=learning_rate
  L2_w=0
  SCGP_layer_weight=SCGP_layer_weight_He
  SCGP_layer_bias=SCGP_layer_bias_He
  options=as.numeric(lapply(option,sum))
  weight=SCGP_layer_weight(data,options)
  bias=SCGP_layer_bias(data,options)
  hidden_layer_input=list()
  hidden_layer_active=list()
  d_hidden_layer=list()
  Error_at_hidden_layer=list()
  slope_hidden_layer=list()
  cost=1
  simple_train=function(data,weight,bias){
    hidden_layer_input=list()
    hidden_layer_active=list()
    if  (length(weight)>=3){
      hidden_layer_input[[1]]=as.matrix(data)%*%as.matrix(weight[[1]])
      hidden_layer_input[[1]]=hidden_layer_input[[1]]+bias[[1]]
      hidden_layer_active[[1]]=acf(hidden_layer_input[[1]])
      for (w in 2:(length(weight)-1)){
        hidden_layer_input[[w]]=as.matrix(hidden_layer_active[[(w-1)]])%*%as.matrix(weight[[w]])
        hidden_layer_input[[w]]=hidden_layer_input[[w]]+bias[[w]]
        hidden_layer_active[[w]]=acf(hidden_layer_input[[w]])
      }
      hidden_layer_input[[length(weight)]]=as.matrix(hidden_layer_active[[(length(weight)-1)]])%*%as.matrix(weight[[length(weight)]])
      hidden_layer_input[[length(weight)]]=hidden_layer_input[[length(weight)]]+bias[[length(weight)]]
      hidden_layer_active[[length(weight)]]=outf(hidden_layer_input[[length(weight)]])}
    if  (length(weight)==1){
      hidden_layer_input[[1]]=as.matrix(data)%*%as.matrix(weight[[1]])
      hidden_layer_input[[1]]=hidden_layer_input[[1]]+bias[[1]]
      hidden_layer_active[[1]]=outf(hidden_layer_input[[1]])}
    if  (length(weight)==2){
      hidden_layer_input[[1]]=as.matrix(data)%*%as.matrix(weight[[1]])
      hidden_layer_input[[1]]=hidden_layer_input[[1]]+bias[[1]]
      hidden_layer_active[[1]]=acf(hidden_layer_input[[1]])

      hidden_layer_input[[2]]=as.matrix(hidden_layer_active[[(1)]])%*%as.matrix(weight[[2]])
      hidden_layer_input[[2]]=hidden_layer_input[[2]]+bias[[2]]
      hidden_layer_active[[2]]=outf(hidden_layer_input[[2]])}
    return(hidden_layer_active[[length(weight)]])
  }
  #### Training
  for(i in 1:training_n){
    #### Forward propagation
    hidden_layer_input[[1]]=as.matrix(data)%*%as.matrix(weight[[1]])
    hidden_layer_input[[1]]=hidden_layer_input[[1]]+bias[[1]]
    if(length(weight)==1){
      hidden_layer_active[[length(weight)]]=outf(hidden_layer_input[[length(weight)]])
    }else{
      if(length(weight)==2){
        hidden_layer_active[[1]]=acf(hidden_layer_input[[1]])
        hidden_layer_input[[length(weight)]]=as.matrix(hidden_layer_active[[(length(weight)-1)]])%*%as.matrix(weight[[length(weight)]])
        hidden_layer_input[[length(weight)]]=hidden_layer_input[[length(weight)]]+bias[[length(weight)]]
        hidden_layer_active[[length(weight)]]=outf(hidden_layer_input[[length(weight)]])
      }else{
        hidden_layer_active[[1]]=acf(hidden_layer_input[[1]])
        for (w in 2:(length(weight)-1)){
          hidden_layer_input[[w]]=as.matrix(hidden_layer_active[[(w-1)]])%*%as.matrix(weight[[w]])
          hidden_layer_input[[w]]=hidden_layer_input[[w]]+bias[[w]]
          hidden_layer_active[[w]]=acf(hidden_layer_input[[w]])
        }
        hidden_layer_input[[length(weight)]]=as.matrix(hidden_layer_active[[(length(weight)-1)]])%*%as.matrix(weight[[length(weight)]])
        hidden_layer_input[[length(weight)]]=hidden_layer_input[[length(weight)]]+bias[[length(weight)]]
        hidden_layer_active[[length(weight)]]=outf(hidden_layer_input[[length(weight)]])
      }}
    #### Back Propagation
    Error_at_hidden_layer[[length(weight)]]=labels-hidden_layer_active[[length(weight)]]
    slope_hidden_layer[[length(weight)]]=derivatives_outf(hidden_layer_input[[length(weight)]])
    d_hidden_layer[[length(weight)]]=Error_at_hidden_layer[[length(weight)]]*slope_hidden_layer[[length(weight)]]
    if(length(weight)==1){
      weight[[1]]=weight[[1]]-d_hidden_layer[[1]]*learning_r-L2_w*(weight[[1]])*learning_r
      bias[[1]]= bias[[1]]
    }else{
      for (w in (length(weight)-1):1){
        Error_at_hidden_layer[[w]]=d_hidden_layer[[(w+1)]]%*%t(weight[[(w+1)]])
        slope_hidden_layer[[w]]=derivatives_acf(hidden_layer_input[[w]])
        d_hidden_layer[[w]]=Error_at_hidden_layer[[w]]*slope_hidden_layer[[w]]
      }
      for (w in (length(weight)):2){
        weight[[w]]=weight[[w]]+(t(hidden_layer_active[[(w-1)]])%*%d_hidden_layer[[w]])*learning_r-L2_w*(weight[[w]])*learning_r
        bias[[w]]= bias[[w]]+colSums(d_hidden_layer[[w]])*learning_r
      }
      weight[[1]]=weight[[1]]+(t(data)%*%d_hidden_layer[[1]])*learning_r-L2_w*(weight[[1]])*learning_r
      bias[[1]]= bias[[1]]+colSums(d_hidden_layer[[1]])*learning_r
    }
    output=simple_train(data,weight,bias)
    cost=c(cost,mean(abs(labels-output)))

    if(i%%message_n==0){
      print(paste("The iteration is",i))
      print(paste("The error value is",cost[length(cost)]))
    }
  }
  SCGP_res=list(weight=weight,bias=bias,cost=cost[-1])
  return(SCGP_res)
}
