#' @title SCGP_gene_pattern
#'
#' @description Identification of gene patterns based on GOSemSim.
#'
#' @param data Input matrix. Rows are samples and columns are nodes.
#'
#' @param k Cluster number.
#'
#' @return A named vector with cluster value.
#'
#' @examples NULL
#'
#' @export SCGP_gene_pattern




SCGP_gene_pattern=function(data,k) {
  Sem_matrix=data
  HC=hclust(dist(Sem_matrix), "ward.D2")
  gene_pattern=cutree(HC,k)
  return(gene_pattern)}
